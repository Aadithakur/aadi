package com.qc.conn;

import java.sql.*;


public class MyConnection {
	
	public static Connection getConnection() {
		Connection con = null;
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/ruby","root","root");
		
			//Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			
			//con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/ruby?" + "user=root&password=root");
		
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		return con;
	}
	

}
