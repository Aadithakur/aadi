package com.qc.conn;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.tomcat.dbcp.dbcp2.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
public class HibernateConfiguration {

	/*
	 * @Bean public LocalSessionFactoryBean sessionFactory() {
	 * LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
	 * sessionFactory.setDataSource(dataSource());
	 * sessionFactory.setHibernateProperties(hibernateProperties()); //return
	 * sessionFactory; return null; }
	 */
	
	
	  @Bean(name="sessionfactory2") public LocalSessionFactoryBean
	  getSessionFactory() { LocalSessionFactoryBean sessionFactory = new
	  LocalSessionFactoryBean(); sessionFactory.setDataSource(dataSource());
	  sessionFactory.setHibernateProperties(hibernateProperties()); return
	  sessionFactory; }
	 
	@Bean
	public DataSource dataSource() {
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setDriverClassName("com.mysql.jdbc.Driver");
		dataSource.setUrl("jdbc:mysql://localhost:3306/ruby");
		dataSource.setUsername("root");
		dataSource.setPassword("root");

		return dataSource;
	}

	
	  @Bean public PlatformTransactionManager hibernateTransactionManager() {
	  HibernateTransactionManager transactionManager = new
	  HibernateTransactionManager();
	  transactionManager.setSessionFactory(getSessionFactory().getObject()); return
	  transactionManager; }
	 

	private final Properties hibernateProperties() {
		Properties hibernateProperties = new Properties();
		hibernateProperties.setProperty(
				"hibernate.hbm2ddl.auto", "update");
		hibernateProperties.setProperty(
				"hibernate.dialect", "org.hibernate.dialect.MySQLDialect");

		return hibernateProperties;
	}

	
}
