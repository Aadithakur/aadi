package com.qc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.qc.UserRegistration;
import com.qc.service.UserService;


@Controller
@SessionAttributes("id")
public class MVCController {
	
	/*
	 * @RequestMapping("/error") public String error() { return "error"; }
	 */
	
	@RequestMapping("/")
	public String index() {
		return "login";
	}
	@RequestMapping("/home")
	public String home() {
		return "login";
	}
	@Autowired
	UserService userService;
	@RequestMapping(value="/register", method = RequestMethod.GET)
	public String registration() {
		return "registration";
	}
	/*
	 * @RequestMapping(value="/login", method = RequestMethod.GET) public String
	 * login() { return "login"; }
	 */
	
	@RequestMapping(value="/userregistration",method = RequestMethod.POST)
	public String userRegistration(ModelMap model, UserRegistration user) {
		
		String msg = userService.registerUserData(user); //calls service method
		
		model.put("msg", msg);
		return "login";
		
	}
	
	@RequestMapping(value="/validateUser", method = RequestMethod.POST)
	public String loginUser(ModelMap model, @RequestParam String id, @RequestParam String password) {
		
		boolean isValidUser = userService.validateUser(id,password);
		
		if(!isValidUser) {
			model.put("msg","Invalid User Id and Password !!!");
			return "login";
		}
		model.put("id", id);
		model.put("password", password);
		//model.put("msg","");
		return "welcome";
	}
	
}
