package com.qc.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qc.UserRegistration;
import com.qc.service.UserService;
import com.qc.dao.UserDao;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserDao userDao;
	@Override
	public String registerUserData(UserRegistration userRegistration) {
		// TODO Auto-generated method stub
		String msg = userDao.saveUserData(userRegistration);
		return msg;
	}

	@Override
	public boolean validateUser(String id, String password) {
		
		return (userDao.userLogin(id,password));
	}

}
