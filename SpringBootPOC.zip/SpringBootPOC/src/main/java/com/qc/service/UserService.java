package com.qc.service;

import com.qc.UserRegistration;

public interface UserService {
	
	public String registerUserData(UserRegistration userRegistration);
	
	public boolean validateUser(String id, String password);

}
