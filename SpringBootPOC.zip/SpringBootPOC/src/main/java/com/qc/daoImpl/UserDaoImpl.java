package com.qc.daoImpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;


import com.qc.UserRegistration;
import com.qc.bean.ConnectionInfo;
import com.qc.bean.Employee;
import com.qc.bean.User;
import com.qc.dao.UserDao;


@Repository
public class UserDaoImpl implements UserDao{

	@Autowired
	@Qualifier("sessionfactory2")
	private SessionFactory sessionFactory;
	
	@Override
	public String saveUserData(UserRegistration user) {
		String registrationStatus="";
		
		
		try {
			User u=new User();
			u.setEmail("aditjan");
			Session session =  sessionFactory.getCurrentSession();
			session.load("1111",UserRegistration.class);
			session.save(u);
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
		/*try {
			Connection conn= MyConnection.getConnection();
				java.sql.PreparedStatement stmt = conn.prepareStatement("insert into QC_User_Detail(id,password,name,address,mobile)values(?,?,?,?,?)");
				
				stmt.setString(1,user.getId());
				stmt.setString(2, user.getPassword());
				stmt.setString(3,user.getName());
				stmt.setString(4,user.getAddress());
				stmt.setString(5,user.getMobile());
				
				int i = stmt.executeUpdate();
	           
	            if (i > 0) {
	            	registrationStatus="Data saved successfully";
	            	System.out.println("Data saved successfully");
	            	
	            }else {
	            	registrationStatus="Failure";
	            }
	            conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
				registrationStatus="Failure : " +e.getMessage() ;
			}*/
		
		return registrationStatus;
	}

	@Override
	public boolean userLogin(String id, String password) {
		
		try {
			/* Connection conn= MyConnection.getConnection(); */
		//	java.sql.Statement stmt=conn.createStatement(); 
			/*
			 * java.sql.PreparedStatement ps=null;
			 * 
			 * //ResultSet rs = stmt.executeQuery("select * from QC_User_Detail where id='"
			 * +id+"'AND password='"+password+"'"); String queryString =
			 * "SELECT * FROM QC_User_Detail where id=? and password=?"; ps =
			 * conn.prepareStatement(queryString); ps.setString(1,id);
			 * ps.setString(2,password); ResultSet rs = ps.executeQuery();
			 * 
			 * while(rs.next()) { return true; } rs.close(); conn.close();
			 */		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

}
